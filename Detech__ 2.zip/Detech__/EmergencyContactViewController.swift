//
//  EmergencyContactViewController.swift
//  Detech_
//
//  Created by Teslim on 4/17/18.
//  Copyright © 2018 Teslim Salami. All rights reserved.
//

import UIKit

class EmergencyContactViewController: UIViewController  {
    
  
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var numberField: UITextField!
    
    
    
    @IBAction func continuePressed(_ sender: UIButton) {

        performSegue(withIdentifier: "passData", sender: self)

    }


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if let destination = segue.destination as?  AccelerDataViewController
        {
            destination.name = nameField.text
            destination.number = numberField.text

        }

    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
    }
        
    
    }

    
    

    

    
    


