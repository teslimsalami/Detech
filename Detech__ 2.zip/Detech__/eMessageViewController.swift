//
//  eMessageViewController.swift
//  Detech_
//
//  Created by Teslim on 4/21/18.
//  Copyright © 2018 Teslim Salami. All rights reserved.
//

import UIKit
import MessageUI

class eMessageViewController: UIViewController, MFMessageComposeViewControllerDelegate {
    
    
    
    @IBOutlet weak var giveName: UILabel!
    @IBOutlet weak var givenNumber: UILabel!
    
    
    
    @IBAction func call911(_ sender: UIButton) {
        
        let url:NSURL = NSURL(string: "tel://7737102955")!
        
        UIApplication.shared.openURL(url as URL)
    }
    
    
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult)
    
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    var name : String?
    var number : String?
    
   
    
    //var phoneNumber = number
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
         if let nameToDisplay = name {
            
            giveName.text = nameToDisplay
            
        }
        
        if let numberToDisplay = number {
            
            givenNumber.text = numberToDisplay
        }
        
        
    }
    
    
    
    @IBAction func sendText(_ sender: Any) {
        
        if (MFMessageComposeViewController.canSendText()) {
            
            let controller = MFMessageComposeViewController()
            
            controller.body = "Help a friend! Seizure Detected!"
            
            controller.recipients = [number] as? [String]
            
            controller.messageComposeDelegate = self
            
            self.present(controller, animated: true, completion: nil)
            
        }
        
    }
    
    
    
    }
    
    
    
//func viewWillDisappear(_ animated: Bool) {
//
//        navigationController?.isNavigationBarHidden = false
//
//    }





