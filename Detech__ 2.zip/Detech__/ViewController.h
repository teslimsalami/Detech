//
//  ViewController.h
//  Detech_
//
//  Created by Teslim on 3/28/18.
//  Copyright © 2018 Teslim Salami. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FFTCalculator.h"


@interface ViewController : UIViewController {
 
    FFTCalculator *fftCalculator;
}

@end
