//
//  AccelerDataViewController.swift
//  Detech_
//
//  Created by Teslim on 4/18/18.
//  Copyright © 2018 Teslim Salami. All rights reserved.
//

import UIKit
import CoreMotion
import Foundation
import AVFoundation
import AudioToolbox

class AccelerDataViewController: UIViewController {
 

    
    @IBOutlet weak var displayLbl: UILabel!
    @IBOutlet weak var displayNumber: UILabel!
    
    @IBOutlet weak var dataText: UILabel!
    
    
    var name: String?
    var number: String?
    
    var motionManager = CMMotionManager()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let nameToDisplay = name {
            
            displayLbl.text = nameToDisplay
        }
        
        if let numberToDisplay = number {
            
            displayNumber.text = numberToDisplay
        }
        

        // Do any additional setup after loading the view.
    }
    
    
    override func viewDidAppear(_ animated: Bool)
    {
        motionManager.accelerometerUpdateInterval = 0.2
        
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!){(data,error) in
            
            if let myData = data
            {
                
                if (myData.acceleration.x > 0 && myData.acceleration.y > 0 && myData.acceleration.z > 0) {// looks for specific change in the data recordings for the 'x,y,z' axis, find range of epileptic seizures
                    
                    
                    
                    do {
                    print ("Seizure Detected!")
                    self.dataText.text = "Seizure Detected!";
                    AudioServicesPlaySystemSound(SystemSoundID(1005))
                    }
                
                print (myData) //To see update of 'x','y'and 'z'plane
            }
                if(self.dataText.text == "Seizure Detected!" )
                {
                    

                //send text to emergency cntact
                
                self.performSegue(withIdentifier: "sendText", sender: self)

                
                }

        }

    }
    
    
    
    
        func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as?  eMessageViewController
        {
            destination.name = displayLbl.text
            destination.number = displayNumber.text
            
        }
        

        
    }
    
    

}

}
