//
//  ContactStruct.swift
//  Detech_
//
//  Created by Teslim on 4/17/18.
//  Copyright © 2018 Teslim Salami. All rights reserved.
//

import Foundation

struct ContactStruct {
    
    let givenName: String
    let familyName: String
    let number: String
}
